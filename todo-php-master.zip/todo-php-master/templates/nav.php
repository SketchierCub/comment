<nav class="navbar fixed-top navbar-expand-sm navbar-dark bg-primary">
    <a class="navbar-brand" href="#">ToDo List</a>     <!--link la pagina curenta-->
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav">
        <a class="nav-item nav-link active" href="/">List Tasks</a> <!-- ??? -->
        <a class="nav-item nav-link active" href="/addtask.php">Add Task</a>
        </div>
    </div>
</nav>
