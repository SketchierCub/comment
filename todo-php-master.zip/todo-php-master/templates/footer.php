<p class="font-weight-light font-italic" style="padding: 20px">
Front-end host: <?php echo gethostname(); ?><br>
Database host: <?php echo $host; ?>

</p>
</body>
  <script src="./js/jquery.min.js"></script>
  <script src="./js/bootstrap.min.js"></script>
</html>